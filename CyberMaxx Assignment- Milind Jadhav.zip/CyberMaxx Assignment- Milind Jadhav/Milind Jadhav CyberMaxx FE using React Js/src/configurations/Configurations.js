module.exports = {
  SignUp: 'https://localhost:44381/api/Auth/SignUp',
  SignIn: 'https://localhost:44381/api/Auth/SignIn',
}
