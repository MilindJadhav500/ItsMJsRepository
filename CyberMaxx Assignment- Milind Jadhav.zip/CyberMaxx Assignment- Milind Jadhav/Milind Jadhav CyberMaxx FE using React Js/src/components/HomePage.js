import React from 'react';

const HomePage = () => {
  return (
    <div
      style={{
        height: '100%',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
      }}
    >
      Welcome To HomePage
    </div>
  );
}

export default HomePage;

