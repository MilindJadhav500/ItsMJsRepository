import React, { useState } from 'react';
//import './SignUp.scss';
import './SignUp.css';
import AuthServices from '../services/AuthServices.js';
import TextField from '@material-ui/core/TextField';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '@material-ui/core/Button';

import Snackbar from '@material-ui/core/Snackbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';

const authServices = new AuthServices();

const SignUp = ({ history }) => {
  const [radioValue, setRadioValue] = useState('User');
  const [userName, setUserName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const [userNameFlag, setUserNameFlag] = useState(false);
  const [passwordFlag, setPasswordFlag] = useState(false);
  const [confirmPasswordFlag, setConfirmPasswordFlag] = useState(false);

  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleClose = (e, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  const checkValidity = () => {
    setUserNameFlag(false);
    setPasswordFlag(false);
    setConfirmPasswordFlag(false);

    if (userName === '') {
      setUserNameFlag(true);
    }
    if (password === '') {
      setPasswordFlag(true);
    }
    if (confirmPassword === '') {
      setConfirmPasswordFlag(true);
    }
  };

  const handleSubmit = (e) => {
    checkValidity();
    if (userName !== '' && password !== '' && confirmPassword !== '') {
      const data = {
        userName: userName,
        password: password,
        confirmPassword: confirmPassword,
        role: radioValue,
      };

      authServices
        .SignUp(data)
        .then((data) => {
          console.log('data : ', data);
          if (data.data.isSuccess) {
            history.push('/SignIn');
          } else {
            console.log('Sign Up Failed');
            setOpen(true);
            setMessage('Sign Up Failed');
          }
        })
        .catch((error) => {
          console.log('error : ', error);
          setOpen(true);
          setMessage('Something Went Wrong');
        });
    } else {
      console.log('Not Acceptable');
      setOpen(true);
      setMessage('Please Fill Required Field');
    }
  };

  const handleRadioChange = (e) => {
    setRadioValue(e.target.value);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'UserName') {
      setUserName(value);
    } else if (name === 'Password') {
      setPassword(value);
    } else if (name === 'ConfirmPassword') {
      setConfirmPassword(value);
    }
  };

  const handleSignIn = (e) => {
    history.push('/SignIn');
  };

  return (
    <div className="SignUp-Container">
      <div className="SignUp-SubContainer">
        <div className="Header">Sign Up</div>
        <div className="Body">
          <form className="form">
            <TextField
              className="TextField"
              name="UserName"
              label="UserName"
              variant="outlined"
              size="small"
              error={userNameFlag}
              value={userName}
              onChange={handleChange}
            />
            <TextField
              className="TextField"
              type="password"
              name="Password"
              label="Password"
              variant="outlined"
              size="small"
              error={passwordFlag}
              value={password}
              onChange={handleChange}
            />
            <TextField
              className="TextField"
              type="password"
              name="ConfirmPassword"
              label="Confirm Password"
              variant="outlined"
              size="small"
              error={confirmPasswordFlag}
              value={confirmPassword}
              onChange={handleChange}
            />
            <RadioGroup
              className="Roles"
              name="Role"
              value={radioValue}
              onChange={handleRadioChange}
            >
              <FormControlLabel
                className="RoleValue"
                value="Admin"
                control={<Radio />}
                label="Admin"
              />
              <FormControlLabel
                className="RoleValue"
                value="User"
                control={<Radio />}
                label="User"
              />
            </RadioGroup>
          </form>
        </div>
        <div className="Buttons">
          <Button className="Btn" color="primary" onClick={handleSignIn}>
            Sign In
          </Button>
          <Button
            className="Btn"
            variant="contained"
            color="primary"
            onClick={handleSubmit}
          >
            Sign Up
          </Button>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message={message}
        action={
          <React.Fragment>
            <Button color="secondary" size="small" onClick={handleClose}>
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
};

export default SignUp;
