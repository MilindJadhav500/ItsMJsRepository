import React, { useState } from 'react';
import AuthServices from '../services/AuthServices';
import './SignUp.css';
import TextField from '@material-ui/core/TextField';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Button from '@material-ui/core/Button';
import Snackbar from '@material-ui/core/Snackbar';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';

const authServices = new AuthServices();

const SignIn = ({ history }) => {
  const [radioValue, setRadioValue] = useState('User');
  const [userName, setUserName] = useState('');
  const [userNameFlag, setUserNameFlag] = useState(false);
  const [password, setPassword] = useState('');
  const [passwordFlag, setPasswordFlag] = useState(false);
  const [open, setOpen] = useState(false);
  const [message, setMessage] = useState('');

  const handleClose = (e, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setOpen(false);
  };

  const handleRadioChange = (e) => {
    setRadioValue(e.target.value);
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name === 'UserName') {
      setUserName(value);
    } else if (name === 'Password') {
      setPassword(value);
    }
  };

  const handleSignUp = (e) => {
    history.push('/');
  };

  const checkValidation = () => {
    setUserNameFlag(false);
    setPasswordFlag(false);

    if (userName === '') {
      setUserNameFlag(true);
    }
    if (password === '') {
      setPasswordFlag(true);
    }
  };

  const handleSubmit = (e) => {
    checkValidation();
    if (userName !== '' && password !== '') {
      let data = {
        userName: userName,
        password: password,
        role: radioValue,
      };
      authServices
        .SignIn(data)
        .then((data) => {
          if (data.data.isSuccess) {
            history.push('/HomePage');
          } else {
            console.log('Something Went Wrong');
            setOpen(true);
            setMessage('LogIn Unsuccessfully');
          }
        })
        .catch((error) => {
          console.log('Error: ', error);
          setOpen(true);
          setMessage('Something Went Wrong');
        });
    } else {
      setOpen(true);
      setMessage('Please Fill Mandatory Fields');
    }
  };

  return (
    <div className="SignUp-Container">
      <div className="SignUp-SubContainer">
        <div className="Header">Sign In</div>
        <div className="Body">
          <form className="form">
            <TextField
              className="TextField"
              name="UserName"
              label="UserName"
              variant="outlined"
              size="small"
              error={userNameFlag}
              value={userName}
              onChange={handleChange}
            />
            <TextField
              className="TextField"
              type="password"
              name="Password"
              label="Password"
              variant="outlined"
              size="small"
              error={passwordFlag}
              value={password}
              onChange={handleChange}
            />
            <RadioGroup
              className="Roles"
              name="Role"
              value={radioValue}
              onChange={handleRadioChange}
            >
              <FormControlLabel
                className="RoleValue"
                value="Admin"
                control={<Radio />}
                label="Admin"
              />
              <FormControlLabel
                className="RoleValue"
                value="User"
                control={<Radio />}
                label="User"
              />
            </RadioGroup>
          </form>
        </div>
        <div className="Buttons" style={{ alignItems: 'flex-start' }}>
          <Button className="Btn" color="primary" onClick={handleSignUp}>
            Sign Up
          </Button>
          <Button
            className="Btn"
            variant="contained"
            color="primary"
            onClick={handleSubmit}
          >
            Sign In
          </Button>
        </div>
      </div>
      <Snackbar
        anchorOrigin={{
          vertical: 'bottom',
          horizontal: 'left',
        }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
        message={message}
        action={
          <React.Fragment>
            <Button color="secondary" size="small" onClick={handleClose}>
              UNDO
            </Button>
            <IconButton
              size="small"
              aria-label="close"
              color="inherit"
              onClick={handleClose}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
          </React.Fragment>
        }
      />
    </div>
  );
};

export default SignIn;
